package br.com.kazuken.kazuken;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KazukenApplication {

	public static void main(String[] args) {
		SpringApplication.run(KazukenApplication.class, args);
	}

}
